# E-Commerce Sales Data Analysis Using SQL

## Project Overview
This beginner-friendly portfolio project analyzes sample e-commerce orders using SQL. The dataset is fictional and created for learning and demonstration.

## Business Questions
1. What is the total revenue?
2. How many orders were placed?
3. Which products generated the most revenue?
4. Which cities generated the most revenue?
5. What is the monthly revenue trend?
6. What is the average order value?

## Files
- `orders.csv` — sample order data
- `analysis.sql` — SQL table setup and analysis queries
- `README.md` — project description and instructions

## Dataset Columns
`order_id`, `order_date`, `customer_name`, `city`, `product`, `category`, `quantity`, `unit_price`

## How to Run
1. Create a database in MySQL or SQLite.
2. Import `orders.csv` into a table named `orders`, or create the table using the SQL file.
3. Run the queries in `analysis.sql`.
4. Review the results and write 2–3 findings in your own words.

## Tools
- SQL (MySQL-compatible queries)
- CSV dataset
- GitHub for project sharing

## Important Note
This is a practice project using fictional sample data. Do not describe it as professional work experience. Add it to your resume as a project after running the queries and understanding the results.
