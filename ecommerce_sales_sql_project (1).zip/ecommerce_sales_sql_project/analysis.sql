-- E-Commerce Sales Data Analysis Using SQL
-- Sample data is provided in orders.csv (fictional practice dataset).
-- MySQL table setup:
CREATE TABLE orders (
    order_id INT PRIMARY KEY,
    order_date DATE,
    customer_name VARCHAR(100),
    city VARCHAR(100),
    product VARCHAR(100),
    category VARCHAR(100),
    quantity INT,
    unit_price DECIMAL(10,2)
);

-- Revenue per order can be calculated as quantity * unit_price.

-- 1. Preview the data
SELECT * FROM orders;

-- 2. Total revenue
SELECT SUM(quantity * unit_price) AS total_revenue
FROM orders;

-- 3. Number of orders
SELECT COUNT(*) AS total_orders
FROM orders;

-- 4. Average order value (one row per order in this sample)
SELECT AVG(quantity * unit_price) AS average_order_value
FROM orders;

-- 5. Revenue by product
SELECT product,
       SUM(quantity * unit_price) AS revenue
FROM orders
GROUP BY product
ORDER BY revenue DESC;

-- 6. Revenue by city
SELECT city,
       SUM(quantity * unit_price) AS revenue
FROM orders
GROUP BY city
ORDER BY revenue DESC;

-- 7. Revenue by category
SELECT category,
       SUM(quantity * unit_price) AS revenue
FROM orders
GROUP BY category
ORDER BY revenue DESC;

-- 8. Monthly revenue trend (MySQL)
SELECT DATE_FORMAT(order_date, '%Y-%m') AS sales_month,
       SUM(quantity * unit_price) AS monthly_revenue
FROM orders
GROUP BY DATE_FORMAT(order_date, '%Y-%m')
ORDER BY sales_month;

-- 9. Best-selling products by quantity
SELECT product,
       SUM(quantity) AS units_sold
FROM orders
GROUP BY product
ORDER BY units_sold DESC;

-- 10. Orders with revenue above 2000
SELECT order_id, order_date, city, product,
       quantity, unit_price,
       quantity * unit_price AS order_revenue
FROM orders
WHERE quantity * unit_price > 2000
ORDER BY order_revenue DESC;
